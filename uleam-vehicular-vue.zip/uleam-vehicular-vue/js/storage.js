const DB_KEY = 'uleamVehicular'

export function initDB() {
  const raw = localStorage.getItem(DB_KEY)
  if (!raw) {
    const initial = {
      usuarios: [
        {
          id: 1,
          tipo: 'sistema',
          nombre: 'Administrador',
          correo: 'admin@uleam.edu.ec',
          usuario: 'admin',
          contrasena: 'admin1',
          rol: 'admin'
        }
      ],
      vehiculos: [],
      movimientos: []
    }
    localStorage.setItem(DB_KEY, JSON.stringify(initial))
  }
}

export function getDB() {
  const raw = localStorage.getItem(DB_KEY)
  if (!raw) return { usuarios: [], vehiculos: [], movimientos: [] }
  try {
    const db = JSON.parse(raw)
    return {
      usuarios: db.usuarios || [],
      vehiculos: db.vehiculos || [],
      movimientos: db.movimientos || []
    }
  } catch {
    localStorage.removeItem(DB_KEY)
    return { usuarios: [], vehiculos: [], movimientos: [] }
  }
}

export function saveDB(db) {
  localStorage.setItem(DB_KEY, JSON.stringify(db))
}