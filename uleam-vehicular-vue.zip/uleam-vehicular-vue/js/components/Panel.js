import { getDB } from '../storage.js'

export default {
  template: `
    <div class="container">
      <h2>Panel Principal</h2>
      <div class="cards">
        <div class="card">
          <h3>Vehículos dentro</h3>
          <p>{{ dentro }}</p>
        </div>
        <div class="card">
          <h3>Vehículos salidos hoy</h3>
          <p>{{ salidasHoy }}</p>
        </div>
        <div class="card alert">
          <h3>Alertas recientes</h3>
          <p>0</p>
        </div>
      </div>
    </div>
  `,
  data() {
    return {
      dentro: 0,
      salidasHoy: 0
    }
  },
  mounted() {
    const db = getDB()
    const hoy = new Date().toISOString().slice(0, 10)

    const ultimos = {}
    db.movimientos.forEach(m => {
      if (!ultimos[m.placa] || new Date(m.fecha) > new Date(ultimos[m.placa].fecha)) {
        ultimos[m.placa] = m
      }
    })

    this.dentro = Object.values(ultimos).filter(m => m.tipo === 'ingreso').length
    this.salidasHoy = db.movimientos.filter(m => m.tipo === 'salida' && m.fecha.startsWith(hoy)).length
  }
}