import { getDB, saveDB } from '../storage.js';

// ---------- helpers ----------
const soloLetras = str => /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/.test(str);
const soloNumeros = str => /^\d+$/.test(str);
const validarCedula = c => soloNumeros(c) && c.length === 10;
const validarCorreo = c => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(c);
const validarTelefono = t => soloNumeros(t) && t.length === 10;
const validarPlaca = p => {
  const placa = p.trim().toUpperCase();
  return /^[A-Z]{3}\d{3,4}$/.test(placa) || /^\d{3}[A-Z]{3}$/.test(placa);
};

export default {
  template: `
    <div class="container">
      <h2>Registrar Usuario y Vehículo</h2>

      <!-- ¿Ya existe el conductor? -->
      <div class="form-section">
        <h3><i class="fas fa-users"></i> ¿Ya existe el conductor?</h3>
        <div class="form-group">
          <label>Seleccionar conductor registrado</label>
          <select v-model="usuarioExistente" aria-describedby="error-usuario-existente">
            <option value="">-- Seleccione un conductor --</option>
            <option v-for="u in conductores" :key="u.id" :value="u.id">
              {{ u.nombre }} {{ u.apellido }} ({{ u.cedula }})
            </option>
          </select>
          <div id="error-usuario-existente" class="error-message">{{ errorUsuarioExistente }}</div>
        </div>
        <button class="btn btn-block" type="button" @click="registrarVehiculoExistente" :disabled="!usuarioExistente || vehiculoError">
          Registrar Vehículo para este conductor
        </button>
      </div>

      <div class="separator"></div>

      <!-- Registrar nuevo conductor -->
      <div class="form-section">
        <h3><i class="fas fa-user-plus"></i> Registrar nuevo conductor</h3>
        <div class="form-grid">
          <div class="form-group">
            <label>Cédula *</label>
            <input
              v-model="nuevo.cedula"
              placeholder="Ej: 1309876543"
              maxlength="10"
              :class="{ invalid: cedulaError }"
              @input="nuevo.cedula = $event.target.value.replace(/\D/g, '')"
            >
            <div v-if="cedulaError" class="error-message live">{{ cedulaError }}</div>
          </div>
          <div class="form-group">
            <label>Nombre *</label>
            <input
              v-model="nuevo.nombre"
              placeholder="Ej: Juan"
              :class="{ invalid: nombreError }"
              @input="nuevo.nombre = $event.target.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, '')"
            >
            <div v-if="nombreError" class="error-message live">{{ nombreError }}</div>
          </div>
          <div class="form-group">
            <label>Apellido *</label>
            <input
              v-model="nuevo.apellido"
              placeholder="Ej: Pérez"
              :class="{ invalid: apellidoError }"
              @input="nuevo.apellido = $event.target.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, '')"
            >
            <div v-if="apellidoError" class="error-message live">{{ apellidoError }}</div>
          </div>
          <div class="form-group">
            <label>Correo *</label>
            <input
              v-model="nuevo.correo"
              type="email"
              placeholder="Ej: juan@uleam.edu.ec"
              :class="{ invalid: correoError }"
            >
            <div v-if="correoError" class="error-message live">{{ correoError }}</div>
          </div>
          <div class="form-group">
            <label>Teléfono</label>
            <input
              v-model="nuevo.telefono"
              placeholder="Ej: 0991234567"
              maxlength="10"
              :class="{ invalid: telefonoError }"
              @input="nuevo.telefono = $event.target.value.replace(/\D/g, '')"
            >
            <div v-if="telefonoError" class="error-message live">{{ telefonoError }}</div>
          </div>
          <div class="form-group">
            <label>Rol *</label>
            <select v-model="nuevo.rol" :class="{ invalid: !nuevo.rol && nuevo.rol !== '' }">
              <option value="">-- Seleccionar --</option>
              <option value="estudiante">Estudiante</option>
              <option value="docente">Docente</option>
              <option value="administrativo">Administrativo</option>
            </select>
            <div v-if="!nuevo.rol && nuevo.rol !== ''" class="error-message live">Seleccione un rol</div>
          </div>
        </div>
      </div>

      <!-- Datos del Vehículo -->
      <div class="form-section">
        <h3><i class="fas fa-car"></i> Datos del Vehículo</h3>
        <div class="form-grid">
          <div class="form-group">
            <label>Placa *</label>
            <input
              v-model="vehiculo.placa"
              placeholder="Ej: ABC123"
              maxlength="7"
              :class="{ invalid: placaError }"
              @input="vehiculo.placa = $event.target.value.replace(/[^a-zA-Z0-9]/g, '').toUpperCase()"
            >
            <div v-if="placaError" class="error-message live">{{ placaError }}</div>
          </div>
          <div class="form-group">
            <label>Marca *</label>
            <input v-model="vehiculo.marca" placeholder="Ej: Toyota" :class="{ invalid: !vehiculo.marca }">
            <div v-if="!vehiculo.marca" class="error-message live">Marca obligatoria</div>
          </div>
          <div class="form-group">
            <label>Modelo *</label>
            <input v-model="vehiculo.modelo" placeholder="Ej: Corolla" :class="{ invalid: !vehiculo.modelo }">
            <div v-if="!vehiculo.modelo" class="error-message live">Modelo obligatorio</div>
          </div>
          <!-- COLOR: solo letras y espacios -->
          <div class="form-group">
            <label>Color *</label>
            <input
              v-model="vehiculo.color"
              placeholder="Ej: Blanco"
              :class="{ invalid: colorError }"
              @input="vehiculo.color = $event.target.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, '')"
            >
            <div v-if="colorError" class="error-message live">{{ colorError }}</div>
          </div>
          <div class="form-group">
            <label>Tipo *</label>
            <select v-model="vehiculo.tipo" :class="{ invalid: !vehiculo.tipo }">
              <option value="">-- Seleccionar --</option>
              <option value="auto">Auto</option>
              <option value="moto">Moto</option>
              <option value="camioneta">Camioneta</option>
              <option value="otro">Otro</option>
            </select>
            <div v-if="!vehiculo.tipo" class="error-message live">Seleccione tipo</div>
          </div>
        </div>
      </div>

      <!-- Botón bloqueado mientras haya errores -->
      <button class="btn" type="button" @click="validarYRegistrar" :disabled="hayErrores">
        Registrar Nuevo Conductor y Vehículo
      </button>
      <div id="mensaje-resumen" class="resumen-error">{{ resumen }}</div>
    </div>
  `,

  data() {
    return {
      usuarioExistente: '',
      conductores: [],
      nuevo: {
        cedula: '',
        nombre: '',
        apellido: '',
        correo: '',
        telefono: '',
        rol: ''
      },
      vehiculo: {
        placa: '',
        marca: '',
        modelo: '',
        color: '',
        tipo: ''
      },
      errores: {},
      resumen: '',
      // ← agregada la variable que faltaba
      errorUsuarioExistente: ''
    };
  },

  computed: {
    // ---------- VALIDACIONES EN TIEMPO REAL ----------
    cedulaError() {
      if (!this.nuevo.cedula) return '';
      if (!soloNumeros(this.nuevo.cedula)) return 'Solo números';
      if (this.nuevo.cedula.length !== 10) return '10 dígitos exactos';
      return '';
    },
    nombreError() {
      if (!this.nuevo.nombre) return '';
      if (!soloLetras(this.nuevo.nombre)) return 'Solo letras y espacios';
      return '';
    },
    apellidoError() {
      if (!this.nuevo.apellido) return '';
      if (!soloLetras(this.nuevo.apellido)) return 'Solo letras y espacios';
      return '';
    },
    correoError() {
      if (!this.nuevo.correo) return '';
      if (!validarCorreo(this.nuevo.correo)) return 'Correo inválido';
      return '';
    },
    telefonoError() {
      if (!this.nuevo.telefono) return '';
      if (!validarTelefono(this.nuevo.telefono)) return '10 dígitos numéricos';
      return '';
    },
    placaError() {
      if (!this.vehiculo.placa) return '';
      if (!validarPlaca(this.vehiculo.placa)) return 'ABC123 o 123ABC';
      return '';
    },
    colorError() {
      if (!this.vehiculo.color) return '';
      if (!/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/.test(this.vehiculo.color)) return 'Solo letras y espacios';
      return '';
    },
    // ¿HAY ERRORES?
    hayErrores() {
      return !!(
        this.cedulaError ||
        this.nombreError ||
        this.apellidoError ||
        this.correoError ||
        this.telefonoError ||
        this.placaError ||
        this.colorError ||
        !this.nuevo.rol ||
        !this.vehiculo.marca ||
        !this.vehiculo.modelo ||
        !this.vehiculo.tipo ||
        this.errorUsuarioExistente   // ← ya existe
      );
    }
  },

  mounted() {
    const db = getDB();
    this.conductores = db.usuarios.filter(u => u.tipo === 'conductor');
  },

  methods: {
    validarYRegistrar() {
      this.errores = {};
      this.resumen = '';

      // 1. Cédula
      if (!this.nuevo.cedula) this.errores.cedula = 'Cédula obligatoria';
      else if (!validarCedula(this.nuevo.cedula)) this.errores.cedula = '10 dígitos numéricos';

      // 2. Nombre
      if (!this.nuevo.nombre) this.errores.nombre = 'Nombre obligatorio';
      else if (!soloLetras(this.nuevo.nombre)) this.errores.nombre = 'Solo letras y espacios';

      // 3. Apellido
      if (!this.nuevo.apellido) this.errores.apellido = 'Apellido obligatorio';
      else if (!soloLetras(this.nuevo.apellido)) this.errores.apellido = 'Solo letras y espacios';

      // 4. Correo
      if (!this.nuevo.correo) this.errores.correo = 'Correo obligatorio';
      else if (!validarCorreo(this.nuevo.correo)) this.errores.correo = 'Correo inválido';

      // 5. Teléfono (opcional)
      if (this.nuevo.telefono && !validarTelefono(this.nuevo.telefono)) {
        this.errores.telefono = '10 dígitos numéricos';
      }

      // 6. Rol
      if (!this.nuevo.rol) this.errores.rol = 'Seleccione un rol';

      // 7. Vehículo
      if (!this.vehiculo.placa) this.errores.placa = 'Placa obligatoria';
      else if (!validarPlaca(this.vehiculo.placa)) this.errores.placa = 'ABC123 o 123ABC';

      if (!this.vehiculo.marca) this.errores.marca = 'Marca obligatoria';
      if (!this.vehiculo.modelo) this.errores.modelo = 'Modelo obligatorio';
      if (!this.vehiculo.color) this.errores.color = 'Color obligatorio';
      if (!this.vehiculo.tipo) this.errores.tipo = 'Seleccione tipo';

      if (Object.keys(this.errores).length) {
        this.resumen = 'Complete los campos marcados';
        return;
      }

      // 8. Guardar
      const db = getDB();

      // 8.1 Usuario
      const nuevoUsuario = {
        id: Date.now(),
        tipo: 'conductor',
        cedula: this.nuevo.cedula,
        nombre: this.nuevo.nombre,
        apellido: this.nuevo.apellido,
        correo: this.nuevo.correo,
        telefono: this.nuevo.telefono || '',
        rol: this.nuevo.rol
      };
      db.usuarios.push(nuevoUsuario);

      // 8.2 Vehículo
      const nuevoVehiculo = {
        id: Date.now() + 1,
        placa: this.vehiculo.placa.toUpperCase().trim(),
        marca: this.vehiculo.marca,
        modelo: this.vehiculo.modelo,
        color: this.vehiculo.color,
        tipo: this.vehiculo.tipo,
        usuarioId: nuevoUsuario.id
      };
      db.vehiculos.push(nuevoVehiculo);

      saveDB(db);
      alert(`Conductor ${nuevoUsuario.nombre} ${nuevoUsuario.apellido} y vehículo ${nuevoVehiculo.placa} registrados.`);
      this.limpiarFormulario();
    },

    registrarVehiculoExistente() {
      this.errores = {};
      if (!this.usuarioExistente) {
        this.errorUsuarioExistente = 'Seleccione un conductor';
        return;
      }
      if (!this.vehiculo.placa || !validarPlaca(this.vehiculo.placa)) {
        this.errores.placa = 'Formato ABC123 o 123ABC';
        return;
      }

      const db = getDB();
      if (db.vehiculos.some(v => v.placa === this.vehiculo.placa.toUpperCase().trim())) {
        this.errores.placa = 'Placa ya registrada';
        return;
      }

      const nuevoVehiculo = {
        id: Date.now(),
        placa: this.vehiculo.placa.toUpperCase().trim(),
        marca: this.vehiculo.marca,
        modelo: this.vehiculo.modelo,
        color: this.vehiculo.color,
        tipo: this.vehiculo.tipo,
        usuarioId: parseInt(this.usuarioExistente)
      };
      db.vehiculos.push(nuevoVehiculo);
      saveDB(db);
      alert(`Vehículo ${nuevoVehiculo.placa} registrado para el conductor seleccionado.`);
      this.limpiarFormulario();
    },

    limpiarFormulario() {
      this.usuarioExistente = '';
      this.nuevo = {
        cedula: '',
        nombre: '',
        apellido: '',
        correo: '',
        telefono: '',
        rol: ''
      };
      this.vehiculo = {
        placa: '',
        marca: '',
        modelo: '',
        color: '',
        tipo: ''
      };
      this.errores = {};
      this.resumen = '';
      this.errorUsuarioExistente = '';
    }
  }
};