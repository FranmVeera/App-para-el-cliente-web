import { getDB, saveDB } from '../storage.js'

function validarPlaca(p) {
  const placa = p.trim().toUpperCase()
  return /^[A-Z]{3}\d{3,4}$/.test(placa) || /^\d{3}[A-Z]{3}$/.test(placa)
}

function formatearFechaHora(iso) {
  const d = new Date(iso)
  if (isNaN(d.getTime())) return '-'
  return d.toLocaleString()
}

export default {
  template: `
    <div class="container">
      <h2>Control de Ingreso y Salida</h2>

      <div class="search-box">
        <label>Buscar por placa</label>
        <input v-model="placaBusqueda" placeholder="Ej: ABC123" />
        <button class="btn-search" @click="buscarVehiculo">Buscar</button>
        <div class="error-message">{{ errorBusqueda }}</div>
      </div>

      <div v-if="vehiculoEncontrado" class="vehicle-card">
        <div class="card-header">
          <strong>Conductor:</strong> {{ nombreConductor }}<br>
          <strong>Último ingreso:</strong> {{ ultimoIngreso }}
        </div>
        <div class="card-actions">
          <button class="control-btn ingreso" @click="registrarIngreso">Registrar Ingreso</button>
          <button class="control-btn salida" @click="registrarSalida">Registrar Salida</button>
        </div>
      </div>
    </div>
  `,
  data() {
    return {
      placaBusqueda: '',
      errorBusqueda: '',
      vehiculoEncontrado: false,
      nombreConductor: '-',
      ultimoIngreso: '-',
      placaActual: ''
    }
  },
  methods: {
    buscarVehiculo() {
      this.errorBusqueda = ''
      this.vehiculoEncontrado = false
      const placa = this.placaBusqueda.trim().toUpperCase()
      if (!placa) {
        this.errorBusqueda = 'Ingrese una placa'
        return
      }
      if (!validarPlaca(placa)) {
        this.errorBusqueda = 'Formato inválido (Ej: ABC123)'
        return
      }
      const db = getDB()
      const vehiculo = db.vehiculos.find(v => v.placa === placa)
      if (!vehiculo) {
        this.errorBusqueda = 'Vehículo no registrado'
        return
      }
      const usuario = db.usuarios.find(u => u.id === vehiculo.usuarioId)
      this.nombreConductor = usuario ? `${usuario.nombre} ${usuario.apellido}` : '-'
      const ult = this.obtenerUltimoMovimiento(placa)
      this.ultimoIngreso = ult ? formatearFechaHora(ult.fecha) : 'Sin registro'
      this.vehiculoEncontrado = true
      this.placaActual = placa
    },
    obtenerUltimoMovimiento(placa) {
      const db = getDB()
      const movs = db.movimientos.filter(m => m.placa === placa)
      if (!movs.length) return null
      movs.sort((a, b) => new Date(b.fecha) - new Date(a.fecha))
      return movs[0]
    },
    registrarIngreso() {
      this.registrarMovimiento('ingreso')
    },
    registrarSalida() {
      this.registrarMovimiento('salida')
    },
    registrarMovimiento(tipo) {
      if (!this.placaActual) {
        this.errorBusqueda = 'Primero busque un vehículo'
        return
      }
      const db = getDB()
      db.movimientos.push({
        id: Date.now(),
        placa: this.placaActual,
        tipo,
        fecha: new Date().toISOString()
      })
      saveDB(db)
      alert(`${tipo === 'ingreso' ? 'Ingreso' : 'Salida'} registrada para ${this.placaActual}`)
      if (tipo === 'ingreso') {
        this.ultimoIngreso = formatearFechaHora(new Date().toISOString())
      }
    }
  }
}