import { getDB, saveDB } from '../storage.js'

function validarCorreo(c) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(c)
}

export default {
  template: `
    <div class="container">
      <h2>Gestión de Usuarios del Sistema</h2>
      <div class="form-grid">
        <div class="form-group">
          <label>Nombre completo <span>*</span></label>
          <input v-model="nombre" />
          <div class="error-message">{{ errores.nombre }}</div>
        </div>
        <div class="form-group">
          <label>Correo <span>*</span></label>
          <input type="email" v-model="correo" />
          <div class="error-message">{{ errores.correo }}</div>
        </div>
        <div class="form-group">
          <label>Rol <span>*</span></label>
          <select v-model="rol">
            <option value="">-- Seleccionar --</option>
            <option value="admin">Administrador</option>
            <option value="guardia">Guardia</option>
          </select>
          <div class="error-message">{{ errores.rol }}</div>
        </div>
        <div class="form-group">
          <label>Contraseña <span>*</span></label>
          <input type="password" v-model="contrasena" minlength="6" />
          <div class="error-message">{{ errores.contrasena }}</div>
        </div>
        <button class="btn" @click="crearUsuario">Crear Usuario</button>
      </div>
    </div>
  `,
  data() {
    return {
      nombre: '',
      correo: '',
      rol: '',
      contrasena: '',
      errores: {}
    }
  },
  methods: {
    crearUsuario() {
      this.errores = {}
      if (!this.nombre) this.errores.nombre = 'Obligatorio'
      if (!this.correo || !validarCorreo(this.correo)) this.errores.correo = 'Correo inválido'
      if (!this.rol) this.errores.rol = 'Seleccione un rol'
      if (!this.contrasena || this.contrasena.length < 6) this.errores.contrasena = 'Mínimo 6 caracteres'
      if (Object.keys(this.errores).length) return

      const db = getDB()
      if (db.usuarios.some(u => u.tipo === 'sistema' && u.correo.toLowerCase() === this.correo.toLowerCase())) {
        this.errores.correo = 'Ya existe un usuario con este correo'
        return
      }

      db.usuarios.push({
        id: Date.now(),
        tipo: 'sistema',
        nombre: this.nombre,
        correo: this.correo,
        rol: this.rol,
        contrasena: this.contrasena
      })
      saveDB(db)

      alert(`Usuario ${this.nombre} creado como ${this.rol}`)
      this.nombre = ''
      this.correo = ''
      this.rol = ''
      this.contrasena = ''
    }
  }
}