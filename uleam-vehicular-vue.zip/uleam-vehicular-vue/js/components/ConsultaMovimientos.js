import { getDB } from '../storage.js';

// ---------- helpers ----------
const soloNumeros = str => /^\d+$/.test(str);
const validarCedula = c => soloNumeros(c) && c.length === 10;
const validarPlaca = p => {
  const placa = p.trim().toUpperCase();
  return /^[A-Z]{3}\d{3,4}$/.test(placa) || /^\d{3}[A-Z]{3}$/.test(placa);
};
const formatearFecha = iso => new Date(iso).toLocaleString();

export default {
  template: `
    <div class="container">
      <h2>Consulta de Movimientos</h2>

      <!-- Fechas -->
      <div class="form-grid full">
        <div class="form-group">
          <label>Fecha inicial</label>
          <input type="date" v-model="fechaInicio" required>
        </div>
        <div class="form-group">
          <label>Fecha final</label>
          <input type="date" v-model="fechaFin" required>
        </div>
      </div>

      <!-- Selector: Cédula o Placa -->
      <div class="form-grid full">
        <div class="form-group">
          <label>Buscar por</label>
          <select v-model="modo" @change="limpiarFiltro">
            <option value="">-- Sin filtro --</option>
            <option value="cedula">Cédula</option>
            <option value="placa">Placa</option>
          </select>
        </div>
        <!-- Campo dinámico: sólo aparece si eligió modo -->
        <div class="form-group" v-if="modo">
          <label>{{ modo === 'cedula' ? 'Cédula' : 'Placa' }} *</label>
          <input
            v-model="filtro"
            :placeholder="modo === 'cedula' ? 'Ej: 1309876543' : 'Ej: ABC123'"
            maxlength="modo === 'cedula' ? 10 : 7"
            :class="{ invalid: filtroError }"
            @input="modo === 'cedula' ? filtroCedula : filtroPlaca"
          >
          <div v-if="filtroError" class="error-message live">{{ filtroError }}</div>
        </div>
      </div>

      <button class="btn" type="button" @click="buscarMovimientos" :disabled="hayErrores">
        Buscar
      </button>

      <!-- Resultados -->
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Fecha y hora</th>
              <th>Placa</th>
              <th>Tipo</th>
              <th>Conductor</th>
            </tr>
          </thead>
          <tbody>
            <tr v-if="resultados.length === 0">
              <td colspan="4" class="no-data">{{ mensajeVacio }}</td>
            </tr>
            <tr v-for="m in resultados" :key="m.id">
              <td>{{ formatearFecha(m.fecha) }}</td>
              <td>{{ m.placa }}</td>
              <td>{{ m.tipo === 'ingreso' ? 'Ingreso' : 'Salida' }}</td>
              <td>{{ getConductor(m.placa) }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `,

  data() {
    return {
      fechaInicio: '',
      fechaFin: '',
      modo: '',               // '' | 'cedula' | 'placa'
      filtro: '',             // texto introducido
      filtroError: '',        // mensaje de error
      resultados: [],         // filas encontradas
      mensajeVacio: 'Seleccione un rango de fechas y pulse Buscar.'
    };
  },

  computed: {
    // ---------- VALIDACIONES EN TIEMPO REAL ----------
    hayErrores() {
      if (!this.fechaInicio || !this.fechaFin) return true;
      if (new Date(this.fechaInicio) > new Date(this.fechaFin)) return true;
      if (this.modo && !this.filtro) return true;
      if (this.filtroError) return true;
      return false;
    }
  },

  methods: {
    // ---------- LIMPIAR ----------
    limpiarFiltro() {
      this.filtro = '';
      this.filtroError = '';
    },

    // ---------- VALIDACIÓN CÉDULA ----------
    filtroCedula() {
      this.filtro = this.filtro.replace(/\D/g, '');
      if (this.filtro.length !== 10) {
        this.filtroError = 'Cédula debe tener 10 dígitos numéricos';
        return;
      }
      const db = getDB();
      const existe = db.usuarios.some(u => u.cedula === this.filtro);
      this.filtroError = existe ? '' : 'La cédula no existe';
    },

    // ---------- VALIDACIÓN PLACA ----------
    filtroPlaca() {
      this.filtro = this.filtro.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
      if (!validarPlaca(this.filtro)) {
        this.filtroError = 'Placa debe ser ABC123 o 123ABC';
        return;
      }
      const db = getDB();
      const existe = db.vehiculos.some(v => v.placa === this.filtro);
      this.filtroError = existe ? '' : 'La placa no existe';
    },

    // ---------- BÚSQUEDA ----------
    buscarMovimientos() {
      this.filtroError = '';
      this.resultados = [];

      // 1. Validación de fechas
      if (!this.fechaInicio || !this.fechaFin) return;
      if (new Date(this.fechaInicio) > new Date(this.fechaFin)) {
        this.mensajeVacio = 'La fecha final no puede ser anterior a la inicial.';
        return;
      }

      // 2. Validación de filtro (si se eligió)
      if (this.modo === 'cedula' && !validarCedula(this.filtro)) {
        this.filtroError = 'Cédula debe tener 10 dígitos numéricos';
        return;
      }
      if (this.modo === 'placa' && !validarPlaca(this.filtro)) {
        this.filtroError = 'Placa debe ser ABC123 o 123ABC';
        return;
      }

      // 3. Buscar
      const db = getDB();
      const inicio = new Date(this.fechaInicio);
      const fin = new Date(this.fechaFin);
      fin.setHours(23, 59, 59, 999);

      let lista = db.movimientos.filter(m => {
        const fechaMov = new Date(m.fecha);
        const enRango = fechaMov >= inicio && fechaMov <= fin;
        if (!enRango) return false;

        // Filtro por placa o cédula
        if (!this.modo) return true; // sin filtro

        if (this.modo === 'placa') {
          return m.placa.toUpperCase() === this.filtro.toUpperCase();
        }

        if (this.modo === 'cedula') {
          const vehiculo = db.vehiculos.find(v => v.placa === m.placa);
          const conductor = vehiculo ? db.usuarios.find(u => u.id === vehiculo.usuarioId) : null;
          return conductor && conductor.cedula === this.filtro;
        }

        return false;
      });

      // 4. ¿Hay resultados?
      if (lista.length === 0) {
        this.mensajeVacio = 'No hay movimientos en el rango de fechas seleccionado.';
        return;
      }

      // 5. Ordenar y mostrar
      this.resultados = lista.sort((a, b) => new Date(b.fecha) - new Date(a.fecha));
      this.mensajeVacio = '';
    },

    // ---------- HELPERS ----------
    formatearFecha(iso) {
      return new Date(iso).toLocaleString();
    },
    getConductor(placa) {
      const db = getDB();
      const vehiculo = db.vehiculos.find(v => v.placa === placa);
      const usuario = vehiculo ? db.usuarios.find(u => u.id === vehiculo.usuarioId) : null;
      return usuario ? `${usuario.nombre} ${usuario.apellido}` : '-';
    }
  },

  mounted() {
    // Fechas por defecto: últimos 7 días
    const hoy = new Date();
    const hace7 = new Date(hoy.getTime() - 6 * 24 * 60 * 60 * 1000);
    this.fechaFin = hoy.toISOString().slice(0, 10);
    this.fechaInicio = hace7.toISOString().slice(0, 10);
  }
};