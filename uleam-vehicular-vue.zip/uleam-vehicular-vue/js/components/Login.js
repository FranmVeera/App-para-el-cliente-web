import { getDB, saveDB } from '../storage.js';

export default {
  template: `
    <div class="login-box">
      <div class="logo-login">
        <img src="assets/LOGO-ULEAM.png" alt="Logo ULEAM" class="logo-img-full">
      </div>

      <!-- Si no hay admin: mostrar registro rápido -->
      <div v-if="!existeAdmin">
        <h2>Registrar primer administrador</h2>
        <div class="form-group">
          <label>Usuario</label>
          <input v-model="nuevo.usuario" placeholder="ej: admin">
        </div>
        <div class="form-group">
          <label>Correo</label>
          <input v-model="nuevo.correo" placeholder="ej: admin@uleam.edu.ec">
        </div>
        <div class="form-group">
          <label>Contraseña</label>
          <input type="password" v-model="nuevo.contrasena" placeholder="mín 6 caracteres">
        </div>
        <button class="btn" @click="crearPrimerAdmin">Crear y entrar</button>
      </div>

      <!-- Si ya hay admin: login normal -->
      <form v-else @submit.prevent="login">
        <h2>Iniciar Sesión</h2>
        <div class="form-group">
          <label>Usuario / Correo</label>
          <input v-model="usuario" required>
          <div class="error-message">{{ errorUsuario }}</div>
        </div>
        <div class="form-group">
          <label>Contraseña</label>
          <input type="password" v-model="contrasena" required>
          <div class="error-message">{{ errorContrasena }}</div>
        </div>
        <button type="submit">Iniciar Sesión</button>
      </form>
    </div>
  `,
  data() {
    return {
      existeAdmin: true,
      usuario: '',
      contrasena: '',
      errorUsuario: '',
      errorContrasena: '',
      nuevo: {
        usuario: 'admin',
        correo: 'admin@uleam.edu.ec',
        contrasena: 'admin123'
      }
    };
  },
  methods: {
    login() {
      this.errorUsuario = '';
      this.errorContrasena = '';

      const input = (this.usuario || '').trim().toLowerCase();
      const pass  = (this.contrasena || '').trim();

      if (!input || !pass) {
        this.errorContrasena = 'Completa usuario y contraseña';
        return;
      }

      const db = getDB();
      const user = db.usuarios.find(u => {
        // Acepta coincidencia por USUARIO, CÉDULA o CORREO
        const matchUsuario = u.usuario?.toLowerCase() === input;
        const matchCedula  = u.cedula?.toLowerCase() === input;
        const matchCorreo  = u.correo?.toLowerCase() === input;
        return matchUsuario || matchCedula || matchCorreo;
      });

      if (!user || user.contrasena !== pass) {
        this.errorContrasena = 'Usuario o contraseña incorrectos';
        return;
      }

      // Si no tiene rol, le ponemos uno
      if (!user.rol) user.rol = 'guest';
      localStorage.setItem('usuarioLogueado', JSON.stringify(user));
      this.$emit('login', user);
    },
    crearPrimerAdmin() {
      if (this.nuevo.usuario.length < 3 || this.nuevo.contrasena.length < 6) {
        alert('Usuario ≥3 chars, contraseña ≥6 chars');
        return;
      }
      const db = getDB();
      db.usuarios.push({
        id: Date.now(),
        tipo: 'sistema',
        nombre: 'Administrador',
        correo: this.nuevo.correo,
        usuario: this.nuevo.usuario,
        contrasena: this.nuevo.contrasena,
        rol: 'admin'
      });
      saveDB(db);
      alert('Administrador creado. Bienvenido.');
      localStorage.setItem('usuarioLogueado', JSON.stringify(db.usuarios[0]));
      this.$emit('login', db.usuarios[0]);
    }
  }
};