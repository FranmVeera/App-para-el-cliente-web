import { createApp } from '../node_modules/vue/dist/vue.esm-browser.js';

import Login from './components/Login.js';
import Panel from './components/Panel.js';
import RegistroUsuarioVehiculo from './components/RegistroUsuarioVehiculo.js';
import ControlIngresoSalida from './components/ControlIngresoSalida.js';
import ConsultaMovimientos from './components/ConsultaMovimientos.js';
import GestionUsuarios from './components/GestionUsuarios.js';

const routes = {
  login: Login,
  panel: Panel,
  registro: RegistroUsuarioVehiculo,
  control: ControlIngresoSalida,
  consulta: ConsultaMovimientos,
  gestion: GestionUsuarios
};

createApp({
  data() {
    return {
      currentView: 'login',
      sidebarVisible: true,
      usuarioLogueado: null   // ← para el filtro por rol
    };
  },
  watch: {
    usuarioLogueado() {
      // fuerza a Vue a re-evaluar el v-if del sidebar
      this.$nextTick(() => this.$forceUpdate());
    }
  },
  computed: {
    currentComponent() {
      return routes[this.currentView];
    }
  },
  methods: {
    navigate(view) {
      this.currentView = view;
    },
    onLogin(user) {
      // si el usuario no tiene rol, le ponemos uno
      if (!user.rol) user.rol = 'guest';
      this.currentView = 'panel';
      this.usuarioLogueado = user;
      localStorage.setItem('usuarioLogueado', JSON.stringify(user));
    },
    logout() {
      localStorage.removeItem('usuarioLogueado');
      this.usuarioLogueado = null;
      this.currentView = 'login';
    },
    toggleSidebar() {
      this.sidebarVisible = !this.sidebarVisible;
    }
  },
  created() {
    // carga usuario al arrancar (por si hay sesión guardada)
    const raw = localStorage.getItem('usuarioLogueado');
    if (raw) this.usuarioLogueado = JSON.parse(raw);
  }
}).mount('#app');